#pragma strict

var wheelF : WheelCollider;

var wheelR : WheelCollider;

var maxTorque : float  = 50;

function Start () {

rigidbody.centerOfMass.y = -0.9;

}

 

function FixedUpdate () {

wheelR.motorTorque = maxTorque * Input.GetAxis("Vertical");

wheelF.steerAngle = 10 * Input.GetAxis("Horizontal");


}